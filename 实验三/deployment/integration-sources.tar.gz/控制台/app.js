const $=id=>document.getElementById(id);
let token='', seq=0, mine=false, online=false, manual=false, direction='', busy=false, taskActive=false, chain=Promise.resolve();
let vectorSupported=false;
let lease='',armed=false,roomState=null,renewing=null;
const held=new Map();
const message=text=>{$('message').textContent=text;};
function applyRoom(room){
  if(!room)return;
  const changed=lease!==room.lease;
  roomState=room;lease=room.lease||'';mine=room.mine;
  if(changed||!mine||room.stopping){held.clear();direction='';armed=false;manual=false;paintKeys();}
  window.RoomUI?.render(room,online);
}
function post(url,data,urgent=false){
  const expectedLease=lease,expectedToken=token;
  const run=async()=>{if(token!==expectedToken)throw Error('连接已更新，请重新操作');const payload=JSON.stringify({...data,lease:expectedLease,seq:++seq});const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','X-Control-Token':token},body:payload,signal:AbortSignal.timeout(url==='/api/ping'?120000:1800)});const result=await response.json();if(!response.ok)throw Error(result.error||'请求失败');if(result.room)applyRoom(result.room);return result;};
  if(urgent)return run();
  const next=chain.then(run);chain=next.catch(()=>{});return next;
}
async function command(value){try{await post('/api/command',{command:value,...(['start','pause','resume','stop'].includes(value)?{experiment:$('experiment').value}:{}),...(value==='start'?{options:window.Workbench.options()}:{})},['zero','stop','pause'].includes(value));return true;}catch(error){message(error.message);return false;}}
function paintKeys(){
  const keys=new Set(held.values());
  document.querySelectorAll('[data-direction]').forEach(b=>b.classList.toggle('active',keys.has(b.dataset.direction)));
  $('keyState').textContent=direction?direction.toUpperCase().split('').join(' + '):'双轴组合';
  document.querySelectorAll('.drive-settings input,.drive-settings button').forEach(input=>input.disabled=held.size>0||(online&&!vectorSupported));
}
function zero(){held.clear();direction='';paintKeys();if(mine&&online)command('zero');}
async function sendDrive(){
  if(!mine||!online||!manual)return;
  const keys=new Set(held.values()),linear=Number(keys.has('w'))-Number(keys.has('s')),angular=Number(keys.has('a'))-Number(keys.has('d'));
  direction=(linear>0?'w':linear<0?'s':'')+(angular>0?'a':angular<0?'d':'');paintKeys();
  if(!direction){await command('zero');return;}
  if(!vectorSupported){
    if(direction.length===1&&Number($('manualSpeed').value)===1.5&&Number($('manualTurn').value)===.3){await command(direction);return;}
    zero();message('组合驾驶和自定义速度需要更新机器人端控制程序');return;
  }
  try{await post('/api/command',{command:'drive',linear,angular,speed:Number($('manualSpeed').value),turn:Number($('manualTurn').value)},true);}
  catch(error){zero();message(error.message);}
}
function hold(key,source='key:'+key){if(!mine||!online||!manual)return;held.set(source,key);sendDrive();}
function release(source){if(held.delete(source))sendDrive();}
$('claim').onclick=async()=>{if(await command('claim')){mine=true;message('已取得控制权');}};
$('ping').onclick=async()=>{
  const label=$('ping').querySelector('span');
  try{$('ping').disabled=true;$('ping').setAttribute('aria-busy','true');label.textContent='检测中…';$('pingState').textContent='正在检测机器人网络';
    const result=await post('/api/ping',{},true);const latency=String(result.output).match(/(?:time|时间)\s*([=<＝＜])\s*(\d+)\s*ms/i);
    if(result.ip)document.querySelector('.address').textContent=result.ip;
    $('pingState').textContent=result.ok?'网络可达'+(latency?' · '+(latency[1]==='<'||latency[1]==='＜'?'<':'')+latency[2]+' ms':''):'网络不可达 · 检查电源与网络';
    $('pingState').dataset.state=result.ok?'ok':'error';message(result.ok?'网络检测完成；控制服务连接状态单独显示':'网络检测未收到机器人回应');
  }catch(error){$('pingState').textContent='检测失败 · '+error.message;message(error.message);}
  finally{$('ping').disabled=false;$('ping').setAttribute('aria-busy','false');label.textContent='检测网络';}
};
document.querySelectorAll('[data-command]').forEach(button=>button.onclick=async()=>{
  zero();const c=button.dataset.command;
  if(c==='manual'){
    if(!mine){if(!await command('claim'))return;mine=true;}
    if(!await command('heartbeat'))return;
    if(await command('manual')){armed=true;manual=true;message('键盘驾驶已启用：W/S 前后，A/D 转向，可组合按下');}
  }else if(await command(c))message('已发送：'+button.textContent);
});
$('zero').onclick=zero;
$('stop').onclick=()=>{zero();command('stop');};
document.querySelectorAll('[data-direction]').forEach(button=>{
  button.addEventListener('pointerdown',event=>{event.preventDefault();button.setPointerCapture(event.pointerId);hold(button.dataset.direction,'pointer:'+event.pointerId);});
  for(const event of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(event,e=>release('pointer:'+e.pointerId));
});
document.addEventListener('keydown',event=>{
  if(event.ctrlKey||event.altKey||event.metaKey||event.target.matches('input,textarea,[contenteditable="true"]')||$('experimentLibrary').open||$('joinDialog')?.open||$('shareDialog')?.open||$('takeoverDialog')?.open)return;
  const key=event.key.toLowerCase();
  if(key===' '){event.preventDefault();zero();if(online||taskActive)command('stop');return;}
  if('wasd'.includes(key)&&key.length===1){event.preventDefault();if(!event.repeat)hold(key);}
});
document.addEventListener('keyup',event=>release('key:'+event.key.toLowerCase()));
function suspend(){zero();armed=false;manual=false;if(mine&&online)command('pause');}
function leaveControl(){
  suspend();if(mine&&token){fetch('/api/room',{method:'POST',headers:{'Content-Type':'application/json','X-Control-Token':token},body:JSON.stringify({action:'release',seq:++seq}),keepalive:true}).catch(()=>{});}mine=false;lease='';
}
window.addEventListener('blur',leaveControl);
document.addEventListener('visibilitychange',()=>{if(document.hidden)leaveControl();});
window.addEventListener('pagehide',leaveControl);
document.addEventListener('control-suspend',suspend);
const labels={WAITING:'等待任务',TURNING:'原地转向',DRIVING:'直线行驶',DONE:'任务完成',FAULT:'故障停车',PAUSED:'已暂停',IDLE:'待命'};
async function refresh(){
  try{
    const response=await fetch('/api/status',{headers:{'X-Control-Token':token},signal:AbortSignal.timeout(1000)});if(!response.ok)throw Error('状态读取失败');const data=await response.json();
    if(token&&data.room&&!data.room.self){mine=false;armed=false;lease='';held.clear();direction='';await openSession();return;}
    online=data.connected && data.age!==null && data.age<1500;
    if(data.robotIp)document.querySelector('.address').textContent=data.robotIp;
    if(data.preview)$('previewBadge').hidden=false;
    applyRoom(data.room);
    if(!mine&&data.task)window.Workbench.syncTask?.(data.task);
    if(!online){mine=false;zero();}
    const state=data.status;manual=state.mode==='manual'&&armed;vectorSupported=state.manual_vector===true;
    paintKeys();
    if(!manual&&held.size)zero();
    $('chassis').textContent=!online?'未连接':state.chassis_mode===1?'网络 / CAN':state.chassis_mode===3?'遥控器接管':'待底盘反馈';
    $('connection').textContent=online?'在线':'离线';$('connection').classList.toggle('online',online);
    if(!data.room){$('claim').disabled=!online||mine;$('claim').textContent=mine?'已取得控制权':'取得控制权';$('lease').textContent=mine?'本窗口正在控制':data.owned?'其他窗口正在控制':'未取得控制权';}
    $('stage').textContent=online?(labels[state.stage]||state.stage||'待命'):'等待连接';$('reason').textContent=online?(state.reason||'控制器在线'):'界面已就绪，等待机器人上线';
    if(online&&state.reason==='Operator stop'){$('stage').textContent='已停止 / 待命';$('reason').textContent='已按操作请求停车；准备实验后可重新启动';}
    $('mode').textContent=!online?'未启用':manual?'手动模式':'自动模式';
    $('driveStatus').textContent=!online?'控制连接未建立':state.manual_block_message?'驾驶受阻：'+state.manual_block_message:!mine?'取得控制权后，可启用键盘驾驶':manual?'键盘驾驶已启用 · 按住 WASD，松开停车':'点击“启用键盘驾驶”恢复或切换手动模式';
    let progress=Number(state.progress)||0,total=Number(state.total_distance)||5;
    for(const key of ['v','w'])$(key).textContent=online&&Number.isFinite(Number(state[key]))?Number(state[key]).toFixed(2):'—';
    $('obstacle').textContent=online?(state.obstacle?'有障碍':'畅通'):'—';$('paused').textContent=online?((state.paused||state.obstacle)?'暂停中':'等待 / 运行'):'等待反馈';
    document.querySelectorAll('[data-command],[data-direction],#stop,#zero').forEach(b=>b.disabled=!online||!mine||!!data.room?.stopping||(b.dataset.direction&&!manual));
    document.querySelector('[data-command="manual"]').disabled=!online||!mine||!!data.room?.stopping;
    const selected=$('experiment').value,lab1=selected==='lab1',eight=selected==='lab2-eight',task=data.task;
    const titles=Object.fromEntries(window.Workbench.items().map(item=>[item.id,item.title]));
    const taskBusy=task&&['preparing','running','stopping'].includes(task.phase);
    taskActive=!!taskBusy;
    const startButton=document.querySelector('[data-command="start"]');
    startButton.textContent=lab1?'开始建图 · 30 秒':data.preparedExperiment===selected?'开始实验':'准备实验';
    startButton.disabled=!online||!mine||taskBusy||!selected||!!data.room?.stopping;
    document.querySelectorAll('[data-command="pause"],[data-command="resume"]').forEach(b=>b.disabled=b.disabled||lab1||!!(task&&['preparing','stopping'].includes(task.phase)));
    $('taskBadge').textContent=window.Workbench.selected()?.badge||'待命';
    if(eight&&state.stage==='DRIVING')$('stage').textContent='八字轨迹跟踪';
    if(selected==='lab3'&&task?.phase==='running'){
      const phases={waiting_for_data:'等待感知',straight:'沿初始路线直行',aligning:'低速转向绕行',aligning_goal:'终点对齐初始朝向',settling_goal:'终点前后微调',following_detour:'沿规划路线绕障',rejoining:'尽快回到原路线',recover_forward:'前进通过受限位置',recover_turn:'优先转向找路',recover_reverse:'短距离后退让位',returning:'回归目标点',blocked:'当前运动范围受阻',exploring:'转向探索',clear_hold:'确认前方畅通',avoid_forward:'绕障直行',finished:'避障任务完成',fault:'避障停车'};
      $('stage').textContent=phases[state.avoidance_state]||$('stage').textContent;
      const reasons={'No route in the observed local window':'当前观测范围内没有可通行路线','Waiting to replan around changed obstacles':'障碍变化，等待重新规划','Swept body or braking path is obstructed':'车身或停车范围受阻','Final heading rotation is obstructed':'终点回正的车身旋转范围受阻','Final heading alignment timeout':'终点朝向未能及时对齐，已停车','No safe route for 12 seconds; reposition or clear the obstacle':'连续 12 秒无安全路线，请清理障碍或重新选择起点','No translational progress for 18 seconds':'连续 18 秒未前进，已停止任务'};
      Object.assign(reasons,{'Seeking a new route after limited progress':'通过转向或倒车寻找新路线','Searching around an obstructed route':'原路受阻，继续搜索','Searching while the route is replanned':'调整姿态并重新规划','Seeking a collision-free direction':'正在寻找可行运动方向','No collision-free forward, turning or reverse motion':'前进、转向和倒车均无法通过车身检查','Goal position adjustment is obstructed':'终点前后微调的车身范围受阻'});
      $('reason').textContent=state.avoidance_version>=2?(reasons[state.avoidance_reason]||state.reason||`距目标 ${Number(state.goal_distance??10).toFixed(2)} m · 已规划 ${state.avoidance_replans??0} 次`):`前方左侧 ${state.front_left_points??0} 点 · 右侧 ${state.front_right_points??0} 点`;
    }
    window.Workbench.lock(taskBusy||!!(data.room?.owner&&!mine));
    if(!lab1&&task?.phase==='preparing'){$('stage').textContent='准备实验中';$('reason').textContent='正在启动传感器、定位和机器人屏幕 RViz';}
    if(!lab1&&task?.phase==='ready'&&state.sensors_ready){$('stage').textContent='准备完成';$('reason').textContent='定位和雷达就绪，点击启动开始新任务';}
    const phases={preparing:'准备中',running:'运行中',stopping:'停止中',stopped:'已停止',completed:'已完成',ready:'准备完成，请再次点击启动',failed:'失败'};
    $('taskLog').textContent=task?`${titles[task.experiment]||task.experiment} · ${phases[task.phase]||task.phase}${task.exitCode!==null?' · 退出码 '+task.exitCode:''}\n${task.log||''}`:'';
    if(lab1&&task?.experiment==='lab1'){$('stage').textContent=phases[task.phase]||task.phase;$('reason').textContent='30 秒建图 → 保存地图 → 验证定位；可独立切换手动驾驶';}
    if(lab1){progress=task?.experiment==='lab1'?task.progress||0:0;total=100;}
    else if(task?.experiment!==selected||['preparing','ready'].includes(task?.phase)){progress=0;total=eight?4*Math.PI*(window.Workbench.options().radius||2):selected==='lab3'?10:5;}
    else if(task?.phase==='completed')progress=total;
    const percent=Math.max(0,Math.min(100,progress/total*100));
    $('progress').textContent=progress.toFixed(lab1?0:2);$('total').textContent=lab1?'100 %':total.toFixed(2)+' m';
    $('progressLabel').textContent=lab1?(task?.progressLabel||'实验阶段'):eight?'八字路线进度':'直线行驶进度';
    if(selected==='lab3')$('progressLabel').textContent='沿原路线进度';
    $('bar').style.width=percent+'%';$('progressPercent').textContent=percent.toFixed(0)+'%';
    $('taskProgress').setAttribute('aria-valuenow',percent.toFixed(0));
    // Other authenticated tabs may still issue an emergency task stop.
    $('stop').disabled=!online&&!taskActive;
    window.RoomUI?.render(data.room,online,data.urls);
  }catch{online=false;mine=false;armed=false;zero();$('connection').textContent='服务连接中断';document.querySelectorAll('[data-command],[data-direction],#stop,#zero,#claim').forEach(b=>b.disabled=true);window.RoomUI?.render(roomState,false);}
}
setInterval(async()=>{
  if(busy||!mine||!online||document.hidden||!document.hasFocus())return;
  busy=true;
  try{await post('/api/command',{command:'heartbeat'});if(direction)await sendDrive();}
  catch(error){mine=false;zero();message(error.message);}finally{busy=false;}
},100);
setInterval(refresh,300);
function openSession(){
  if(renewing)return renewing;
  renewing=fetch('/api/session').then(r=>r.json()).then(data=>{if(!data.token)throw Error('无法建立会话');token=data.token;applyRoom(data.room);window.RoomUI?.init({act:(action,extra)=>{if(['release','takeover'].includes(action))zero();return post('/api/room',{action,...extra},true);},online:()=>online,message},data);}).finally(()=>{renewing=null;});return renewing;
}
openSession().then(refresh).catch(()=>message('无法连接共享服务，请刷新页面'));
fetch('/api/experiments').then(r=>r.json()).then(data=>window.Workbench.load(data.experiments)).catch(()=>message('无法加载实验列表'));
